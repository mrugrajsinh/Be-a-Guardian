'use strict';
/**
 * Saathi - women's safety SOS prototype server (zero required dependencies).
 *
 * Flow: a woman holds the SOS button -> the server finds approved, on-duty helpers
 * with a fresh location inside an expanding radius -> alerts them live (server-sent
 * events) and by push notification (optional `web-push` package), and optionally
 * texts her emergency contacts. Her screen always offers "Call 112": volunteers are
 * a supplement to the police, never a substitute.
 */
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

/* ------------------------------------------------------------------ config */
const PORT = Number(process.env.PORT) || 3000;
const APP_NAME = process.env.APP_NAME || 'Be a Guardian';
const EMERGENCY_NUMBER = process.env.EMERGENCY_NUMBER || '112';
const DEFAULT_CC = process.env.DEFAULT_COUNTRY_CODE || '91';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PUBLIC_DIR = path.join(__dirname, 'public');
const RADIUS_STEPS = (process.env.RADIUS_STEPS_M || '1000,2500,5000').split(',').map(Number);
const EXPAND_AFTER_MS = Number(process.env.EXPAND_AFTER_MS) || 45000;
const LOCATION_MAX_AGE_MS = (Number(process.env.LOCATION_MAX_AGE_MIN) || 30) * 60000;
const ALERT_TTL_MS = (Number(process.env.ALERT_TTL_MIN) || 60) * 60000;
const MAX_ALERTS_PER_HOUR = Number(process.env.MAX_ALERTS_PER_HOUR) || 5;
const KEEP_ALERT_RECORDS_MS = 30 * 24 * 3600 * 1000;
const TRUST_PROXY = process.env.TRUST_PROXY !== '0';
// Per-IP limits. Kept generous because a campus or office shares one IP address.
const RATE_REGISTER = Number(process.env.RATE_REGISTER_PER_HOUR) || 60;
const RATE_LOGIN = Number(process.env.RATE_LOGIN_PER_15MIN) || 60;

/* Optional: lock-screen push notifications. Everything else works without it. */
let webpush = null;
try { webpush = require(process.env.WEBPUSH_MODULE || 'web-push'); }
catch { console.log('Note: "web-push" is not installed, so lock-screen push is off. In-app alerts still work.'); }

/* ---------------------------------------------------------------- database */
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_FILE = path.join(DATA_DIR, 'db.json');
let db = { users: {}, alerts: {}, vapid: null, adminKey: null };
try {
  if (fs.existsSync(DB_FILE)) db = Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE, 'utf8')));
} catch (e) {
  // Refuse to start rather than overwrite a damaged file with an empty database.
  console.error('Could not read database file:', e.message);
  process.exit(1);
}
let saveTimer = null;
function flush() {
  if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db));
  fs.renameSync(tmp, DB_FILE);
}
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => { saveTimer = null; try { flush(); } catch (e) { console.error('save failed', e.message); } }, 200);
}
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { try { flush(); } catch {} process.exit(0); });

/* -------------------------------------------------------------------- keys */
const b64u = (b) => Buffer.from(b).toString('base64url');
function genVapid() {
  const ecdh = crypto.createECDH('prime256v1');
  ecdh.generateKeys();
  const priv = ecdh.getPrivateKey();
  return { publicKey: b64u(ecdh.getPublicKey()), privateKey: b64u(Buffer.concat([Buffer.alloc(32 - priv.length), priv])) };
}
if (process.env.VAPID_PUBLIC && process.env.VAPID_PRIVATE) {
  db.vapid = { publicKey: process.env.VAPID_PUBLIC, privateKey: process.env.VAPID_PRIVATE };
} else if (!db.vapid) { db.vapid = genVapid(); save(); }
if (webpush) {
  try { webpush.setVapidDetails(process.env.VAPID_SUBJECT || 'mailto:admin@example.com', db.vapid.publicKey, db.vapid.privateKey); }
  catch (e) { console.error('Push setup failed, push disabled:', e.message); webpush = null; }
}

let ADMIN_KEY = process.env.ADMIN_KEY;
if (!ADMIN_KEY) {
  if (!db.adminKey) {
    db.adminKey = crypto.randomBytes(12).toString('hex');
    save();
    console.log('\n  Generated admin key (open /admin.html and paste it):  ' + db.adminKey + '\n');
  }
  ADMIN_KEY = db.adminKey;
}

/* ----------------------------------------------------------------- helpers */
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');
const rid = (n = 8) => crypto.randomBytes(n).toString('hex');
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });
const safeEq = (a, b) => crypto.timingSafeEqual(Buffer.from(sha(a), 'hex'), Buffer.from(sha(b), 'hex'));

function haversine(lat1, lng1, lat2, lng2) {
  const R = 6371000, rad = Math.PI / 180;
  const dLat = (lat2 - lat1) * rad, dLng = (lng2 - lng1) * rad;
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
}
const fmtDist = (m) => (m < 1000 ? Math.round(m / 10) * 10 + ' m' : (m / 1000).toFixed(1) + ' km');

function normPhone(p) {
  let d = String(p || '').replace(/[^\d+]/g, '');
  if (d.startsWith('+')) d = d.slice(1);
  else { d = d.replace(/^0+/, ''); if (d.length === 10) d = DEFAULT_CC + d; }
  return /^\d{10,15}$/.test(d) ? d : null;
}
function cleanContacts(list) {
  const out = [];
  for (const c of Array.isArray(list) ? list.slice(0, 5) : []) {
    const name = String((c && c.name) || '').trim().slice(0, 60);
    const phone = normPhone(c && c.phone);
    if (name && phone) out.push({ name, phone });
  }
  return out;
}
function parseLoc(b) {
  const lat = Number(b && b.lat), lng = Number(b && b.lng), acc = Number(b && b.acc) || null;
  if (b == null || b.lat == null || b.lng == null) return null;
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
  return { lat, lng, acc };
}

/* PINs (used to log in and to end an alert) */
const hashPin = (pin, salt) => crypto.scryptSync(String(pin), salt, 32).toString('hex');
function checkPin(u, pin) {
  const now = Date.now();
  if (u.lockedUntil && u.lockedUntil > now) return 'locked';
  const ok = crypto.timingSafeEqual(Buffer.from(hashPin(pin, u.pinSalt), 'hex'), Buffer.from(u.pinHash, 'hex'));
  if (ok) { u.pinFails = 0; return 'ok'; }
  u.pinFails = (u.pinFails || 0) + 1;
  if (u.pinFails >= 5) { u.lockedUntil = now + 15 * 60000; u.pinFails = 0; }
  save();
  return 'bad';
}

/* Tiny in-memory rate limiter */
const hits = new Map();
function limit(key, max, windowMs) {
  const now = Date.now();
  const arr = (hits.get(key) || []).filter((t) => now - t < windowMs);
  if (arr.length >= max) { hits.set(key, arr); return false; }
  arr.push(now); hits.set(key, arr); return true;
}
setInterval(() => hits.clear(), 3600e3).unref();

/* Indexes */
const byToken = new Map();
const byPhone = new Map();
function reindex() {
  byToken.clear(); byPhone.clear();
  for (const u of Object.values(db.users)) {
    byPhone.set(u.phone, u.id);
    for (const t of u.tokens || []) byToken.set(t, u.id);
  }
}
reindex();
function issueToken(u) {
  const token = crypto.randomBytes(24).toString('hex');
  u.tokens = [...(u.tokens || []), sha(token)].slice(-5);
  reindex(); save();
  return token;
}
const publicUser = (u) => ({
  id: u.id, role: u.role, name: u.name, phone: u.phone, status: u.status,
  onDuty: !!u.onDuty, contacts: u.contacts || [], pushEnabled: !!(u.pushSubs && u.pushSubs.length),
});

/* Live helper locations are kept ONLY in memory - never written to disk. */
const live = new Map(); // userId -> {lat,lng,acc,at}

/* --------------------------------------------------------------- real-time */
const clients = new Map(); // userId -> Set<http.ServerResponse> (server-sent-event streams)
const tickets = new Map(); // one-time stream tickets, so the login token never appears in a URL
const writeEvent = (res, msg) => { try { res.write('data: ' + JSON.stringify(msg) + '\n\n'); } catch {} };
function send(uid, msg) { const set = clients.get(uid); if (set) for (const res of set) writeEvent(res, msg); }
setInterval(() => {
  for (const set of clients.values()) for (const res of set) { try { res.write(': ping\n\n'); } catch {} }
  const now = Date.now();
  for (const [t, v] of tickets) if (v.exp < now) tickets.delete(t);
}, 20000).unref();

function sendPush(u, payload) {
  if (!webpush) return;
  for (const sub of (u.pushSubs || []).slice()) {
    Promise.resolve()
      .then(() => webpush.sendNotification(sub, JSON.stringify(payload), { TTL: 600, urgency: 'high' }))
      .catch((e) => {
        if (e && (e.statusCode === 404 || e.statusCode === 410)) {
          u.pushSubs = (u.pushSubs || []).filter((s) => s.endpoint !== sub.endpoint);
          save();
        } else console.error('push failed:', (e && (e.statusCode || e.message)) || e);
      });
  }
}

/* ------------------------------------------------------------------ alerts */
const timers = new Map();
const activeAlertOf = (uid) => Object.values(db.alerts).find((a) => a.userId === uid && a.status === 'active') || null;
const responders = (a) => Object.values(a.responses).filter((r) => r.status === 'coming' || r.status === 'arrived');

function womanView(a) {
  const r = responders(a);
  return {
    id: a.id, status: a.status, createdAt: a.createdAt, radiusM: RADIUS_STEPS[a.radiusIdx],
    notified: a.notified.length, coming: r.length, arrived: r.filter((x) => x.status === 'arrived').length,
    lat: a.lat, lng: a.lng,
  };
}
function helperView(a, hid) {
  const mine = a.responses[hid];
  const others = responders(a).length - (mine && (mine.status === 'coming' || mine.status === 'arrived') ? 1 : 0);
  return {
    id: a.id, name: a.firstName, lat: a.lat, lng: a.lng, acc: a.acc,
    createdAt: a.createdAt, updatedAt: a.updatedAt, my: mine ? mine.status : null, othersComing: others,
  };
}
function broadcast(a) {
  send(a.userId, { type: 'my_alert', alert: womanView(a) });
  for (const hid of a.notified) {
    const r = a.responses[hid];
    if (r && r.status === 'cannot') continue;
    send(hid, { type: 'helper_alert', alert: helperView(a, hid) });
  }
}

function eligibleHelpers() {
  const now = Date.now(), out = [];
  for (const u of Object.values(db.users)) {
    if (u.role !== 'helper' || u.status !== 'approved' || !u.onDuty) continue;
    const l = live.get(u.id);
    if (!l || now - l.at > LOCATION_MAX_AGE_MS) continue;
    out.push({ u, l });
  }
  return out;
}
function notifyOne(a, u, d) {
  a.notified.push(u.id);
  send(u.id, { type: 'helper_alert', alert: helperView(a, u.id) });
  sendPush(u, {
    title: 'Someone nearby needs help',
    body: `${a.firstName} pressed SOS about ${fmtDist(d)} from you. Tap to see where. Call ${EMERGENCY_NUMBER} too.`,
    alertId: a.id, url: '/?alert=' + a.id,
  });
}
function notifyHelpers(a) {
  const radius = RADIUS_STEPS[a.radiusIdx];
  let n = 0;
  for (const { u, l } of eligibleHelpers()) {
    if (u.id === a.userId || a.notified.includes(u.id)) continue;
    const d = haversine(a.lat, a.lng, l.lat, l.lng);
    if (d > radius) continue;
    notifyOne(a, u, d); n++;
  }
  if (n) save();
  return n;
}
function notifyHelperIfNear(u) { // a helper opened the app / moved while an alert is live
  const l = live.get(u.id);
  if (!l) return;
  for (const a of Object.values(db.alerts)) {
    if (a.status !== 'active' || a.notified.includes(u.id) || a.userId === u.id) continue;
    const d = haversine(a.lat, a.lng, l.lat, l.lng);
    if (d <= RADIUS_STEPS[a.radiusIdx]) { notifyOne(a, u, d); save(); broadcast(a); }
  }
}
function scheduleExpansion(a) {
  clearTimeout(timers.get(a.id));
  if (a.status !== 'active' || a.radiusIdx >= RADIUS_STEPS.length - 1) return;
  timers.set(a.id, setTimeout(() => {
    const cur = db.alerts[a.id];
    if (!cur || cur.status !== 'active') return;
    if (responders(cur).length === 0) { cur.radiusIdx++; notifyHelpers(cur); broadcast(cur); save(); }
    scheduleExpansion(cur);
  }, EXPAND_AFTER_MS));
}
async function smsContacts(user, a) { // optional, only if Twilio env vars are set
  const sid = process.env.TWILIO_SID, tok = process.env.TWILIO_TOKEN, from = process.env.TWILIO_FROM;
  if (!sid || !tok || !from) return;
  const text = `${user.name} pressed the ${APP_NAME} SOS button and may be in danger. Her location when she pressed it: https://maps.google.com/?q=${a.lat},${a.lng} . Please call her, and call ${EMERGENCY_NUMBER} if you cannot reach her.`;
  for (const c of user.contacts || []) {
    try {
      const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
        method: 'POST',
        headers: { Authorization: 'Basic ' + Buffer.from(sid + ':' + tok).toString('base64') },
        body: new URLSearchParams({ To: '+' + c.phone, From: from, Body: text }),
      });
      if (!r.ok) console.error('sms failed', r.status);
    } catch (e) { console.error('sms error', e.message); }
  }
}
function startAlert(user, loc) {
  const now = Date.now();
  const recent = Object.values(db.alerts).filter((x) => x.userId === user.id && now - x.createdAt < 3600e3).length;
  if (recent >= MAX_ALERTS_PER_HOUR) return null;
  const a = {
    id: rid(8), userId: user.id, firstName: user.name.split(/\s+/)[0],
    lat: loc.lat, lng: loc.lng, acc: loc.acc, createdAt: now, updatedAt: now,
    status: 'active', radiusIdx: 0, notified: [], responses: {}, endedAt: null, endReason: null,
  };
  db.alerts[a.id] = a;
  notifyHelpers(a);
  scheduleExpansion(a);
  smsContacts(user, a);
  broadcast(a);
  save();
  return a;
}
function endAlert(a, reason) {
  if (a.status !== 'active') return;
  a.status = 'ended'; a.endedAt = Date.now(); a.endReason = reason;
  a.lat = a.lng = a.acc = null; // privacy: her location is erased as soon as the alert ends
  clearTimeout(timers.get(a.id)); timers.delete(a.id);
  send(a.userId, { type: 'my_alert_end', id: a.id, reason });
  for (const hid of a.notified) send(hid, { type: 'helper_alert_end', id: a.id, reason });
  save();
}
setInterval(() => {
  const now = Date.now();
  for (const a of Object.values(db.alerts)) {
    if (a.status === 'active' && now - a.createdAt > ALERT_TTL_MS) endAlert(a, 'expired');
    if (a.status === 'ended' && now - a.endedAt > KEEP_ALERT_RECORDS_MS) { delete db.alerts[a.id]; save(); }
  }
  for (const [id, l] of live) if (now - l.at > 24 * 3600e3) live.delete(id);
}, 30000).unref();
for (const a of Object.values(db.alerts)) if (a.status === 'active') scheduleExpansion(a); // resume after a restart

/* ------------------------------------------------------- tiny http router */
const routes = [];
function route(method, pattern, ...handlers) {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:([a-z]+)/gi, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
  routes.push({ method, re, keys, handlers });
}
const get = (p, ...h) => route('GET', p, ...h);
const post = (p, ...h) => route('POST', p, ...h);
function matchRoute(method, p) {
  for (const r of routes) {
    if (r.method !== method) continue;
    const m = r.re.exec(p);
    if (m) return { handlers: r.handlers, params: Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])])) };
  }
  return null;
}
function runChain(handlers, req, res) {
  let i = 0;
  const next = () => { const h = handlers[i++]; if (h) h(req, res, next); };
  next();
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > 20000) { reject(Object.assign(new Error('Request too large'), { status: 413 })); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      const s = Buffer.concat(chunks).toString('utf8');
      if (!s) return resolve({});
      try { resolve(JSON.parse(s)); } catch { reject(Object.assign(new Error('Bad request'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}
function clientIp(req) {
  if (TRUST_PROXY) {
    const xf = String(req.headers['x-forwarded-for'] || '').split(',').map((s) => s.trim()).filter(Boolean);
    if (xf.length) return xf[xf.length - 1]; // the entry added by our own proxy
  }
  return req.socket.remoteAddress || '?';
}
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.json': 'application/json', '.ico': 'image/x-icon',
};
function serveStatic(req, res) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return bad(res, 'Not found', 404);
  let p = decodeURIComponent(req.path);
  if (p === '/admin') p = '/admin.html';
  if (p.endsWith('/')) p += 'index.html';
  const file = path.join(PUBLIC_DIR, p);
  if (!file.startsWith(PUBLIC_DIR + path.sep)) return bad(res, 'Not found', 404);
  fs.readFile(file, (err, buf) => {
    if (err) return bad(res, 'Not found', 404);
    res.setHeader('Content-Type', MIME[path.extname(file)] || 'application/octet-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.end(req.method === 'HEAD' ? undefined : buf);
  });
}

const server = http.createServer(async (req, res) => {
  res.status = (c) => { res.statusCode = c; return res; };
  res.json = (o) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    res.end(JSON.stringify(o));
  };
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'geolocation=(self), camera=(), microphone=()');
  res.setHeader('Content-Security-Policy',
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; media-src 'self' data:; worker-src 'self'; manifest-src 'self'; frame-ancestors 'none'");
  req.ip = clientIp(req);
  try {
    const url = new URL(req.url, 'http://localhost');
    req.path = url.pathname; req.query = url.searchParams;
    if (req.path.startsWith('/api/') || req.path === '/healthz' || req.path === '/manifest.webmanifest') {
      const r = matchRoute(req.method, req.path);
      if (!r) return bad(res, 'Not found', 404);
      req.params = r.params;
      req.body = req.method === 'POST' ? await readBody(req) : {};
      return runChain(r.handlers, req, res);
    }
    serveStatic(req, res);
  } catch (e) {
    if (res.headersSent) return res.end();
    if (e && e.status) return bad(res, e.message, e.status);
    console.error('server error:', e && e.message);
    bad(res, 'Server error', 500);
  }
});

/* ---------------------------------------------------------- auth middleware */
function auth(req, res, next) {
  const h = req.headers.authorization || '';
  const t = h.startsWith('Bearer ') ? h.slice(7) : '';
  const uid = t && byToken.get(sha(t));
  const u = uid && db.users[uid];
  if (!u || u.status === 'banned') return bad(res, 'Please log in again', 401);
  req.user = u; req.tokenHash = sha(t);
  next();
}
function adminAuth(req, res, next) {
  const k = String(req.headers['x-admin-key'] || '');
  if (k && safeEq(k, ADMIN_KEY)) return next();
  if (!limit('admfail:' + req.ip, 10, 600e3)) return bad(res, 'Too many attempts', 429);
  bad(res, 'Wrong admin key', 401);
}

/* ------------------------------------------------------------------ routes */
get('/healthz', (req, res) => res.json({ ok: true }));
get('/api/config', (req, res) => res.json({
  appName: APP_NAME, emergencyNumber: EMERGENCY_NUMBER, vapidPublicKey: db.vapid.publicKey, pushAvailable: !!webpush,
}));
get('/manifest.webmanifest', (req, res) => {
  res.setHeader('Content-Type', 'application/manifest+json');
  res.end(JSON.stringify({
    name: APP_NAME, short_name: APP_NAME, start_url: '/', display: 'standalone',
    background_color: '#ffffff', theme_color: '#b3123f',
    icons: [
      { src: '/icon-192.png', sizes: '192x192', type: 'image/png' },
      { src: '/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' },
    ],
  }));
});

/* ---- accounts */
post('/api/register', (req, res) => {
  if (!limit('reg:' + req.ip, RATE_REGISTER, 3600e3)) return bad(res, 'Too many attempts. Try again later.', 429);
  const b = req.body || {};
  const role = b.role === 'helper' ? 'helper' : b.role === 'woman' ? 'woman' : null;
  if (!role) return bad(res, 'Choose how you want to use the app');
  const name = String(b.name || '').trim().slice(0, 60);
  if (!name) return bad(res, 'Please enter your name');
  const phone = normPhone(b.phone);
  if (!phone) return bad(res, 'Enter a valid phone number');
  if (byPhone.has(phone)) return bad(res, 'This phone number is already registered. Please log in.');
  const pin = String(b.pin || '');
  if (!/^\d{4,6}$/.test(pin)) return bad(res, 'PIN must be 4 to 6 digits');
  if (!b.acceptTerms) return bad(res, 'Please accept the terms to continue');

  const u = { id: rid(8), role, name, phone, createdAt: Date.now(), acceptedTermsAt: Date.now(), strikes: 0 };
  u.pinSalt = rid(8); u.pinHash = hashPin(pin, u.pinSalt);
  if (role === 'woman') {
    u.contacts = cleanContacts(b.contacts);
    if (!u.contacts.length) return bad(res, 'Add at least one emergency contact (name and phone)');
    u.status = 'active';
  } else {
    const idLast4 = String(b.idLast4 || '');
    if (!/^\d{4}$/.test(idLast4)) return bad(res, 'Enter the last 4 digits of your ID');
    u.idType = String(b.idType || 'ID').slice(0, 30); u.idLast4 = idLast4; // never store the full ID number
    u.note = String(b.note || '').slice(0, 300);
    u.status = 'pending'; u.onDuty = false;
  }
  db.users[u.id] = u;
  reindex();
  res.json({ token: issueToken(u), me: publicUser(u) });
});
post('/api/login', (req, res) => {
  if (!limit('login:' + req.ip, RATE_LOGIN, 900e3)) return bad(res, 'Too many attempts. Try again later.', 429);
  const phone = normPhone(req.body.phone);
  const u = phone && db.users[byPhone.get(phone)];
  if (!u || u.status === 'banned') return bad(res, 'Wrong phone number or PIN', 401);
  const r = checkPin(u, req.body.pin || '');
  if (r === 'locked') return bad(res, 'Too many wrong PINs. Try again in 15 minutes.', 429);
  if (r !== 'ok') return bad(res, 'Wrong phone number or PIN', 401);
  res.json({ token: issueToken(u), me: publicUser(u) });
});
post('/api/logout', auth, (req, res) => {
  req.user.tokens = (req.user.tokens || []).filter((t) => t !== req.tokenHash);
  req.user.pushSubs = []; live.delete(req.user.id);
  reindex(); save(); res.json({ ok: true });
});
get('/api/state', auth, (req, res) => {
  const u = req.user, out = { me: publicUser(u), alert: null, alerts: [] };
  if (u.role === 'woman') { const a = activeAlertOf(u.id); out.alert = a ? womanView(a) : null; }
  else out.alerts = Object.values(db.alerts)
    .filter((a) => a.status === 'active' && a.notified.includes(u.id) && !(a.responses[u.id] && a.responses[u.id].status === 'cannot'))
    .map((a) => helperView(a, u.id));
  res.json(out);
});
post('/api/me/contacts', auth, (req, res) => {
  if (req.user.role !== 'woman') return bad(res, 'Not allowed', 403);
  const contacts = cleanContacts(req.body.contacts);
  if (!contacts.length) return bad(res, 'Keep at least one emergency contact');
  req.user.contacts = contacts; save(); res.json({ me: publicUser(req.user) });
});

/* ---- live stream (server-sent events) */
post('/api/stream-ticket', auth, (req, res) => {
  const t = crypto.randomBytes(16).toString('hex');
  tickets.set(t, { uid: req.user.id, exp: Date.now() + 30000 });
  res.json({ ticket: t });
});
get('/api/stream', (req, res) => {
  const t = req.query.get('t') || '';
  const tk = tickets.get(t); tickets.delete(t);
  const u = tk && tk.exp > Date.now() && db.users[tk.uid];
  if (!u || u.status === 'banned') return bad(res, 'Please log in again', 401);
  res.writeHead(200, {
    'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive', 'X-Accel-Buffering': 'no',
  });
  res.write('retry: 3000\n\n');
  if (!clients.has(u.id)) clients.set(u.id, new Set());
  clients.get(u.id).add(res);
  res.on('close', () => { const s = clients.get(u.id); if (s) { s.delete(res); if (!s.size) clients.delete(u.id); } });
  writeEvent(res, { type: 'ready' });
  if (u.role === 'woman') { const a = activeAlertOf(u.id); if (a) writeEvent(res, { type: 'my_alert', alert: womanView(a) }); }
  else for (const a of Object.values(db.alerts)) {
    const r = a.responses[u.id];
    if (a.status === 'active' && a.notified.includes(u.id) && !(r && r.status === 'cannot')) writeEvent(res, { type: 'helper_alert', alert: helperView(a, u.id) });
  }
});

/* ---- helpers: push, duty, location */
post('/api/push/subscribe', auth, (req, res) => {
  const s = req.body.subscription;
  if (!s || typeof s.endpoint !== 'string' || !s.keys || !s.keys.p256dh || !s.keys.auth) return bad(res, 'Bad subscription');
  const u = req.user;
  u.pushSubs = [...(u.pushSubs || []).filter((x) => x.endpoint !== s.endpoint), { endpoint: s.endpoint, keys: { p256dh: s.keys.p256dh, auth: s.keys.auth } }].slice(-5);
  save(); res.json({ ok: true });
});
post('/api/duty', auth, (req, res) => {
  const u = req.user;
  if (u.role !== 'helper' || u.status !== 'approved') return bad(res, 'Your helper account is not approved yet', 403);
  u.onDuty = !!req.body.onDuty;
  if (!u.onDuty) live.delete(u.id);
  save(); res.json({ me: publicUser(u) });
});
post('/api/location', auth, (req, res) => {
  const loc = parseLoc(req.body);
  if (!loc) return bad(res, 'Bad location');
  const u = req.user;
  if (u.role === 'helper') {
    if (u.status === 'approved' && u.onDuty) { live.set(u.id, { ...loc, at: Date.now() }); notifyHelperIfNear(u); }
  } else {
    const a = activeAlertOf(u.id);
    if (a) { Object.assign(a, loc, { updatedAt: Date.now() }); broadcast(a); }
  }
  res.json({ ok: true });
});

/* ---- SOS */
post('/api/sos', auth, (req, res) => {
  const u = req.user;
  if (u.role !== 'woman') return bad(res, 'Only safety-button accounts can send SOS', 403);
  const loc = parseLoc(req.body);
  if (!loc) return bad(res, 'Location unavailable. Turn on location, and call ' + EMERGENCY_NUMBER + '.');
  let a = activeAlertOf(u.id);
  if (a) { Object.assign(a, loc, { updatedAt: Date.now() }); broadcast(a); }
  else {
    a = startAlert(u, loc);
    if (!a) return bad(res, 'Too many alerts in the last hour. Please call ' + EMERGENCY_NUMBER + '.', 429);
  }
  res.json({ alert: womanView(a), emergencyNumber: EMERGENCY_NUMBER });
});
post('/api/sos/:id/cancel', auth, (req, res) => {
  const a = db.alerts[req.params.id];
  if (!a || a.userId !== req.user.id || a.status !== 'active') return bad(res, 'No active alert', 404);
  const r = checkPin(req.user, req.body.pin || '');
  if (r === 'locked') return bad(res, 'Too many wrong PINs. Try again in 15 minutes.', 429);
  if (r !== 'ok') return bad(res, 'Wrong PIN', 403);
  endAlert(a, req.body.reason === 'false_alarm' ? 'false_alarm' : 'safe');
  res.json({ ok: true });
});
post('/api/sos/:id/respond', auth, (req, res) => {
  const a = db.alerts[req.params.id], u = req.user, r = req.body.response;
  if (!a || a.status !== 'active' || u.role !== 'helper' || !a.notified.includes(u.id)) return bad(res, 'Alert not found', 404);
  if (!['coming', 'cannot', 'arrived'].includes(r)) return bad(res, 'Bad response');
  a.responses[u.id] = { status: r, at: Date.now() };
  save(); broadcast(a);
  if (r === 'cannot') send(u.id, { type: 'helper_alert_end', id: a.id, reason: 'declined' });
  res.json({ ok: true });
});

/* ---- admin */
get('/api/admin/overview', adminAuth, (req, res) => {
  const users = Object.values(db.users);
  const helpers = users.filter((u) => u.role === 'helper').map((u) => ({
    id: u.id, name: u.name, phone: u.phone, status: u.status, idType: u.idType, idLast4: u.idLast4,
    note: u.note, createdAt: u.createdAt, onDuty: !!u.onDuty, strikes: u.strikes || 0,
  }));
  const women = users.filter((u) => u.role === 'woman').map((u) => ({
    id: u.id, name: u.name, phone: u.phone, status: u.status, strikes: u.strikes || 0, createdAt: u.createdAt,
  }));
  const alerts = Object.values(db.alerts).sort((a, b) => b.createdAt - a.createdAt).slice(0, 50).map((a) => ({
    id: a.id, user: (db.users[a.userId] || {}).name, phone: (db.users[a.userId] || {}).phone,
    createdAt: a.createdAt, status: a.status, endReason: a.endReason,
    notified: a.notified.length, coming: responders(a).length, flaggedFalse: !!a.flaggedFalse,
  }));
  res.json({ helpers, women, alerts, onDutyNow: eligibleHelpers().length });
});
post('/api/admin/users/:id/:action', adminAuth, (req, res) => {
  const u = db.users[req.params.id];
  if (!u) return bad(res, 'Not found', 404);
  const act = req.params.action;
  if (act === 'approve' && u.role === 'helper') u.status = 'approved';
  else if (act === 'reject' && u.role === 'helper') { u.status = 'rejected'; u.onDuty = false; live.delete(u.id); }
  else if (act === 'ban') { u.status = 'banned'; u.onDuty = false; live.delete(u.id); }
  else if (act === 'unban') u.status = u.role === 'helper' ? 'pending' : 'active';
  else return bad(res, 'Unknown action');
  save(); res.json({ ok: true });
});
post('/api/admin/alerts/:id/false', adminAuth, (req, res) => {
  const a = db.alerts[req.params.id];
  if (!a) return bad(res, 'Not found', 404);
  if (!a.flaggedFalse) {
    a.flaggedFalse = true;
    const u = db.users[a.userId];
    if (u) { u.strikes = (u.strikes || 0) + 1; if (u.strikes >= 3) u.status = 'banned'; }
    save();
  }
  res.json({ ok: true });
});

server.listen(PORT, () => console.log(`${APP_NAME} server listening on port ${PORT}`));
